package net.harimurti.tv.model

class Category {
    var name: String? = null
    var channels: ArrayList<Channel>? = null
}