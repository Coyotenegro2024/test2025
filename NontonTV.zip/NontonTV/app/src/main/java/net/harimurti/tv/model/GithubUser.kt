package net.harimurti.tv.model

class GithubUser {
    lateinit var login: String
    lateinit var url: String
    var contributions = 0
}