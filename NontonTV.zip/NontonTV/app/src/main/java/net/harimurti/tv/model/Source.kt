package net.harimurti.tv.model

class Source {
    var path: String = ""
    var active = true
}